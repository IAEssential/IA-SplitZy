import 'package:flutter/material.dart';

void main() {
  runApp(const SplitZyApp());
}

const navy = Color(0xFF07182D);
const teal = Color(0xFF12D6C5);
const lime = Color(0xFFB8F23B);

class SplitZyApp extends StatelessWidget {
  const SplitZyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'IA Split-Zy',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: teal, brightness: Brightness.light),
        scaffoldBackgroundColor: const Color(0xFFF5F8FC),
        appBarTheme: const AppBarTheme(backgroundColor: navy, foregroundColor: Colors.white),
      ),
      home: const HomeScreen(),
    );
  }
}

class Expense {
  Expense({required this.title, required this.amount, required this.paidBy, required this.date});
  final String title;
  final double amount;
  final String paidBy;
  final DateTime date;
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final List<Expense> expenses = [
    Expense(title: 'PTCL Internet', amount: 1800, paidBy: 'Iftikhar', date: DateTime.now()),
    Expense(title: 'Water bottles', amount: 630, paidBy: 'Areeba', date: DateTime.now()),
  ];

  double get total => expenses.fold(0, (sum, item) => sum + item.amount);

  Future<void> addExpense() async {
    final result = await Navigator.push<Expense>(
      context, MaterialPageRoute(builder: (_) => const AddExpenseScreen()));
    if (result != null) setState(() => expenses.insert(0, result));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('IA Split-Zy', style: TextStyle(fontWeight: FontWeight.bold)),
          Text('Split Smart. Stay Connected.', style: TextStyle(fontSize: 11, color: teal)),
        ]),
        actions: [
          IconButton(onPressed: () {}, icon: const Icon(Icons.notifications_outlined)),
          IconButton(onPressed: () {}, icon: const Icon(Icons.account_circle_outlined)),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: addExpense,
        backgroundColor: navy,
        foregroundColor: Colors.white,
        icon: const Icon(Icons.add),
        label: const Text('Add Expense'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [navy, Color(0xFF123B62)]),
              borderRadius: BorderRadius.circular(22),
            ),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('GROUP BALANCE', style: TextStyle(color: Colors.white70, letterSpacing: 1.2)),
              const SizedBox(height: 8),
              Text('Rs. ${total.toStringAsFixed(0)}', style: const TextStyle(color: Colors.white, fontSize: 32, fontWeight: FontWeight.bold)),
              const SizedBox(height: 4),
              const Text('Total recorded expenses', style: TextStyle(color: Colors.white70)),
              const SizedBox(height: 18),
              Row(children: [
                Expanded(child: _balanceTile('I Paid', 'Rs. 1,800', teal)),
                const SizedBox(width: 10),
                Expanded(child: _balanceTile('You Paid', 'Rs. 630', lime)),
              ]),
            ]),
          ),
          const SizedBox(height: 18),
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            const Text('Quick Actions', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            TextButton(onPressed: addExpense, child: const Text('Add new')),
          ]),
          Row(children: [
            Expanded(child: _quickAction(Icons.receipt_long, 'Add Bill', addExpense)),
            const SizedBox(width: 10),
            Expanded(child: _quickAction(Icons.water_drop_outlined, 'Water', addExpense)),
            const SizedBox(width: 10),
            Expanded(child: _quickAction(Icons.people_alt_outlined, 'Invite', () => _invite(context))),
          ]),
          const SizedBox(height: 22),
          const Text('Recent Expenses', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          ...expenses.map((e) => Card(
            elevation: 0,
            child: ListTile(
              leading: CircleAvatar(backgroundColor: const Color(0xFFE0F7F4), child: Icon(Icons.receipt, color: navy)),
              title: Text(e.title, style: const TextStyle(fontWeight: FontWeight.w600)),
              subtitle: Text('Paid by ${e.paidBy} • ${e.date.day}/${e.date.month}/${e.date.year}'),
              trailing: Text('Rs. ${e.amount.toStringAsFixed(0)}', style: const TextStyle(fontWeight: FontWeight.bold)),
            ),
          )),
          const SizedBox(height: 90),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: 0,
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.groups_outlined), label: 'Groups'),
          NavigationDestination(icon: Icon(Icons.bar_chart_outlined), label: 'Reports'),
          NavigationDestination(icon: Icon(Icons.settings_outlined), label: 'Settings'),
        ],
      ),
    );
  }

  Widget _balanceTile(String title, String value, Color accent) => Container(
    padding: const EdgeInsets.all(12),
    decoration: BoxDecoration(color: Colors.white.withOpacity(.10), borderRadius: BorderRadius.circular(14)),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(title, style: const TextStyle(color: Colors.white70)),
      const SizedBox(height: 4),
      Text(value, style: TextStyle(color: accent, fontWeight: FontWeight.bold, fontSize: 16)),
    ]),
  );

  Widget _quickAction(IconData icon, String label, VoidCallback onTap) => InkWell(
    onTap: onTap,
    borderRadius: BorderRadius.circular(16),
    child: Container(
      padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 8),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
      child: Column(children: [Icon(icon, color: navy), const SizedBox(height: 8), Text(label, style: const TextStyle(fontWeight: FontWeight.w600))]),
    ),
  );
}

class AddExpenseScreen extends StatefulWidget {
  const AddExpenseScreen({super.key});
  @override
  State<AddExpenseScreen> createState() => _AddExpenseScreenState();
}

class _AddExpenseScreenState extends State<AddExpenseScreen> {
  final titleController = TextEditingController();
  final amountController = TextEditingController();
  String payer = 'Iftikhar';
  String category = 'General';

  @override
  void dispose() {
    titleController.dispose();
    amountController.dispose();
    super.dispose();
  }

  void save() {
    final amount = double.tryParse(amountController.text.trim());
    if (titleController.text.trim().isEmpty || amount == null || amount <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Enter a description and valid amount.')));
      return;
    }
    Navigator.pop(context, Expense(title: titleController.text.trim(), amount: amount, paidBy: payer, date: DateTime.now()));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Add Expense')),
    body: ListView(padding: const EdgeInsets.all(20), children: [
      const Text('Expense details', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
      const SizedBox(height: 18),
      TextField(controller: titleController, decoration: const InputDecoration(labelText: 'What was this for?', border: OutlineInputBorder(), prefixIcon: Icon(Icons.edit))),
      const SizedBox(height: 14),
      TextField(controller: amountController, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'Amount (PKR)', border: OutlineInputBorder(), prefixIcon: Icon(Icons.currency_exchange))),
      const SizedBox(height: 14),
      DropdownButtonFormField<String>(value: payer, decoration: const InputDecoration(labelText: 'Paid by', border: OutlineInputBorder()), items: const [
        DropdownMenuItem(value: 'Iftikhar', child: Text('I Paid')),
        DropdownMenuItem(value: 'Areeba', child: Text('You Paid')),
      ], onChanged: (v) => setState(() => payer = v ?? payer)),
      const SizedBox(height: 14),
      DropdownButtonFormField<String>(value: category, decoration: const InputDecoration(labelText: 'Category', border: OutlineInputBorder()), items: const [
        DropdownMenuItem(value: 'General', child: Text('General')),
        DropdownMenuItem(value: 'Utilities', child: Text('Utilities')),
        DropdownMenuItem(value: 'Water', child: Text('Water')),
        DropdownMenuItem(value: 'Groceries', child: Text('Groceries')),
        DropdownMenuItem(value: 'Transport', child: Text('Transport')),
      ], onChanged: (v) => setState(() => category = v ?? category)),
      const SizedBox(height: 20),
      OutlinedButton.icon(onPressed: () {}, icon: const Icon(Icons.attach_file), label: const Text('Attach bill / receipt (coming next milestone)')),
      const SizedBox(height: 20),
      FilledButton(onPressed: save, style: FilledButton.styleFrom(backgroundColor: navy, padding: const EdgeInsets.all(16)), child: const Text('Save Expense')),
    ]),
  );
}

void _invite(BuildContext context) {
  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('WhatsApp invite link will be enabled after accounts and backend setup.')));
}
