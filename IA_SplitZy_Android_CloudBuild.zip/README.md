# IA Split-Zy — Android Cloud Build

This is a Flutter starter project prepared for cloud compilation from a phone.

## Cloud APK build
1. Upload this project to a GitHub repository.
2. GitHub Actions will run the workflow in `.github/workflows/android-apk.yml`.
3. When the workflow completes, open its run page and download the `IA-SplitZy-debug-apk` artifact.
4. Extract the artifact ZIP and install the APK on your Android device.

This prototype is UI-only and uses sample in-memory expenses. Authentication, online sync, receipt storage, invitations and billing are not yet implemented.
